// Example of dynamic content on the dashboard
window.onload = function() {
    const courseList = [
        { title: 'Machine Learning Basics', description: 'An introductory course to ML concepts.' },
        { title: 'Advanced Python', description: 'Deep dive into Python programming for data science.' },
        { title: 'AI for Everyone', description: 'Learn how AI is shaping the future of technology.' },
    ];

    const courseListContainer = document.getElementById('course-list');

    courseList.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.classList.add('course-item');
        
        const courseTitle = document.createElement('h3');
        courseTitle.textContent = course.title;
        
        const courseDescription = document.createElement('p');
        courseDescription.textContent = course.description;
        
        courseItem.appendChild(courseTitle);
        courseItem.appendChild(courseDescription);
        
        courseListContainer.appendChild(courseItem);
    });
};
// Example of interaction on the landing page
document.getElementById('getStartedBtn').addEventListener('click', function() {
    window.location.href = 'dashboard.html';  // Redirect to the dashboard page
});
